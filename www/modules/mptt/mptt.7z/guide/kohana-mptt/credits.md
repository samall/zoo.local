This module based on [kohana-mptt](https://github.com/kiall/kohana3-orm_mptt) module by [kiall](https://github.com/kiall/)

Features
--------

- Kohana coding standards are apllied in this modules
- Documentation included

Credits
-------

Special thankes to authors of original module

- Kiall Mac Innes
- Mathew Davies
- Mike Parkin