Introduction
============

This module apllied Joe Celko's Nested Sets algorythm for Kohana PHP framework.
