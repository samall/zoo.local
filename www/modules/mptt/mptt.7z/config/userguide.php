<?php defined('SYSPATH') or die('No direct script access.');

return array
(
	'modules' => array
	(
		'kohana-tree' => array
		(
			'enabled'     => TRUE,
			'name'        => 'Kohana-MPTT',
			'description' => 'Modified Preorder Tree Traversal module based on Nested Sets algorythm',
			'copyright'   => '&copy; 2010-2011',
		)
	)
);
