MPTT (Modified Preorder Tree Traversal) module for Kohana 3
===========================================================

This module apllied Joe Celko's Nested Sets algorythm for Kohana PHP framework.

This module based on [kohana3-orm_mptt](https://github.com/kiall/kohana3-orm_mptt) module by [kiall](https://github.com/kiall/)

Installation
------------

1. `git submodule add https://github.com/Leemo/kohana-mptt.git modules/mptt`
2. `cd modules/mptt && git submodule update --init`
3. Enable mptt module in your bootstrap.php file
4. Extend `ORM_MPTT`

Features
--------

- Kohana coding standards are apllied in this modules
- Documentation included

Credits
-------

Special thankes to authors of original module

- Kiall Mac Innes
- Mathew Davies
- Mike Parkin
